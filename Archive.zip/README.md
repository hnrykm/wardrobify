# Wardrobify

Team:

- Kevin Almonte - Shoes
- Henry Kim - Hats

## Design

## Shoes microservice

Explain your models and integration with the wardrobe
microservice, here.

## Hats microservice

Explain your models and integration with the wardrobe
microservice, here.
